package main

import (
	router "awesomeProject/2022/callback/Router"
	apitag "awesomeProject/2022/callback/apitag"
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	router.InitRouter(r, apitag.Tag)
	r.Run(":9080")
	//fmt.Println()
}
