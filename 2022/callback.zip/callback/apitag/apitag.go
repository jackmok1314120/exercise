package apitag

var Tag = []string{
	"api",
}
