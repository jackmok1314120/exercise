package callbackRouter

import (
	"github.com/gin-gonic/gin"
	log "github.com/sirupsen/logrus"
	"net/http"
	"os"
)

func init() {
	// 获取日志文件句柄
	// 以 只写入文件|没有时创建|文件尾部追加 的形式打开这个文件
	logFile, err := os.OpenFile(`/Users/jackmok/go/src/awesomeProject/2022/callback/log/商家回调日志.log`, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0666)
	if err != nil {
		panic(err)
	}
	// 设置存储位置
	log.SetOutput(logFile)
}

func LoadCallBackRouter(group *gin.RouterGroup) {
	group.POST("/callback", callback)
}

func callback(ctx *gin.Context) {
	ctx.Header("Access-Control-Allow-Origin", "*")
	ctx.Header("Access-Control-Allow-Headers", "Content-Type")
	ctx.Header("content-type", "application/json")
	//ctx.JSON(http.StatusOK, map[string]interface{}{})
	data := map[string]interface{}{}

	ctx.BindJSON(&data)
	log.Println(data)
	//fmt.Println("收到的data:", data)
	//log.Fatal("%v", &data)
	ctx.JSON(http.StatusOK, gin.H{
		"massage": http.StatusOK,
		"data":    data,
	})
	return
}
