package router

import (
	"awesomeProject/2022/callback/Router/callbackRouter"
	"fmt"
	"github.com/gin-gonic/gin"
	"strings"
)

func InitRouter(r *gin.Engine, g []string) {
	for i, _ := range g {
		matchRouter(g[i], r)
		//fmt.Println("打印g[i]:", g[i])
	}

}
func matchRouter(tag string, r *gin.Engine) {
	path := fmt.Sprintf("%s/%s", strings.ToLower(tag), strings.ToLower(""))
	switch tag {
	case "api":
		callbackRouter.LoadCallBackRouter(r.Group(path))
		break
	}
}
